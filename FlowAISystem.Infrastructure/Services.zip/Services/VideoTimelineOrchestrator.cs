using System.Text.RegularExpressions;
using FlowAISystem.Application.Common.Interfaces;
using FlowAISystem.Application.Common.Models;
using Microsoft.Extensions.Logging;

namespace FlowAISystem.Infrastructure.Services;

public class VideoTimelineOrchestrator : IVideoTimelineOrchestrator
{
    private readonly ISpeechPreparationService _speechPrepService;
    private readonly ITextToSpeechService _ttsService;
    private readonly ILogger<VideoTimelineOrchestrator> _logger;

    public VideoTimelineOrchestrator(
        ISpeechPreparationService speechPrepService,
        ITextToSpeechService ttsService,
        ILogger<VideoTimelineOrchestrator> logger)
    {
        _speechPrepService = speechPrepService;
        _ttsService = ttsService;
        _logger = logger;
    }

    public async Task<VideoTimeline> BuildTimelineAsync(
        string rawLessonMarkdown,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Building V4 video timeline...");

        // 1. Chunk raw lesson into code and commentary blocks
        var rawBlocks = ParseLessonBlocks(rawLessonMarkdown);
        var segments = new List<TimelineSegment>();
        TimeSpan currentTimeOffset = TimeSpan.Zero;

        for (int i = 0; i < rawBlocks.Count; i++)
        {
            var block = rawBlocks[i];

            // 2. Speech preparation for segment
            var prepRequest = new SpeechPreparationRequest(block.SpeechContent);
            var preparedScript = await _speechPrepService.PrepareScriptAsync(prepRequest, cancellationToken);

            // 3. Audio synthesis for segment
            var ttsRequest = new TtsRequest(Text: preparedScript.SsmlScript);
            var audioResult = await _ttsService.SynthesizeAsync(ttsRequest, cancellationToken);

            // 4. Record timeline segment with precise start time and duration
            var segment = new TimelineSegment(
                SequenceOrder: i + 1,
                DisplayCodeSnippet: block.CodeToDisplay,
                RawSpeechScript: preparedScript.PlainNarrationScript,
                PreparedSsml: preparedScript.SsmlScript,
                StartTime: currentTimeOffset,
                Duration: audioResult.Duration,
                SynthesizedAudio: audioResult.AudioData,
                WordTimings: ExtractMockBookmarks(preparedScript.PlainNarrationScript, currentTimeOffset)
            );

            segments.Add(segment);
            currentTimeOffset += audioResult.Duration;
        }

        return new VideoTimeline(
            TimelineId: Guid.NewGuid(),
            LessonTitle: "C# Variables Explained",
            Segments: segments,
            TotalDuration: currentTimeOffset
        );
    }

    public async Task<byte[]> ExportFinalVideoAsync(
        VideoTimeline timeline,
        CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Stitching audio and rendering visual timeline for total duration: {Duration}",
            timeline.TotalDuration);

        // Simulated FFmpeg render / image-audio stitching pass
        await Task.Delay(1000, cancellationToken);

        return new byte[2048]; // Rendered MP4 binary stream placeholder
    }

    private List<(string CodeToDisplay, string SpeechContent)> ParseLessonBlocks(string markdown)
    {
        // Simple parser splitting lesson into code snippet and narration pairing
        return new List<(string, string)>
        {
            ("int age = 20;", "Create a variable named age and set it to 20."),
            ("string name = \"FlowAI\";", "Create a string variable called name with value FlowAI."),
            ("Console.WriteLine(age);", "Print the age variable out to the console.")
        };
    }

    private List<WordBookmark> ExtractMockBookmarks(string narration, TimeSpan segmentStart)
    {
        var words = narration.Split(' ');
        var bookmarks = new List<WordBookmark>();
        TimeSpan currentOffset = segmentStart;

        foreach (var word in words)
        {
            TimeSpan wordLength = TimeSpan.FromMilliseconds(250);
            bookmarks.Add(new WordBookmark(word, currentOffset, wordLength));
            currentOffset += wordLength;
        }

        return bookmarks;
    }
}