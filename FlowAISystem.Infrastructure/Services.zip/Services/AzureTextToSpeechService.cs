using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using FlowAISystem.Application.Common.Interfaces;
using FlowAISystem.Application.Common.Models;
using FlowAISystem.Infrastructure.Configuration;
using Microsoft.CognitiveServices.Speech;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace FlowAISystem.Infrastructure.Services;

public class AzureTextToSpeechService : ITextToSpeechService
{
    private readonly AzureSpeechOptions _options;
    private readonly ILogger<AzureTextToSpeechService> _logger;

    public AzureTextToSpeechService(
        IOptions<AzureSpeechOptions> options,
        ILogger<AzureTextToSpeechService> logger)
    {
        _options = options.Value;
        _logger = logger;
    }

    public async Task<TtsResult> SynthesizeAsync(TtsRequest request, CancellationToken cancellationToken = default)
    {
        var speechConfig = SpeechConfig.FromSubscription(_options.SubscriptionKey, _options.Region);

        // Output audio format suitable for video timeline integration (24kHz 16bit Mono MP3)
        speechConfig.SetSpeechSynthesisOutputFormat(SpeechSynthesisOutputFormat.Audio24Khz160KBitRateMonoMp3);

        var wordBookmarks = new List<WordBookmark>();

        // Null speech output config allows synthesis directly into memory stream
        using var synthesizer = new SpeechSynthesizer(speechConfig, null);

        // 1. Subscribe to SynthesisWordBoundary events for word-level sync
        synthesizer.SynthesisWordBoundary += (s, e) =>
        {
            if (e.BoundaryType == SpeechSynthesisBoundaryType.Word)
            {
                var audioOffset = TimeSpan.FromTicks((long)e.AudioOffset);
                var duration = e.Duration;

                _logger.LogDebug("Word boundary event: '{Text}' at {Offset}ms", e.Text, audioOffset.TotalMilliseconds);

                // Pass all 5 parameters required by WordBookmark
                wordBookmarks.Add(new WordBookmark(
                    Word: e.Text,
                    Offset: audioOffset,
                    Duration: duration,
                    TextOffset: e.TextOffset,
                    WordLength: e.WordLength
                ));
            }
        };

        _logger.LogInformation("Sending SSML payload to Azure Speech SDK...");

        // 2. Synthesize SSML string
        using var result = await synthesizer.SpeakSsmlAsync(request.Text);

        if (result.Reason == ResultReason.SynthesizingAudioCompleted)
        {
            byte[] audioData = result.AudioData;
            TimeSpan audioDuration = result.AudioDuration;

            _logger.LogInformation("Azure synthesis completed. Received {Bytes} bytes ({Duration}s)",
                audioData.Length, audioDuration.TotalSeconds);

            return new TtsResult(
                AudioData: audioData,
                ContentType: "audio/mp3",
                Duration: audioDuration,
                WordBookmarks: wordBookmarks
            );
        }
        else if (result.Reason == ResultReason.Canceled)
        {
            var cancellation = SpeechSynthesisCancellationDetails.FromResult(result);
            _logger.LogError("Azure Speech synthesis failed: Reason={Reason}, ErrorDetails={Error}",
                cancellation.Reason, cancellation.ErrorDetails);

            throw new InvalidOperationException($"Azure Speech Synthesis Canceled: {cancellation.ErrorDetails}");
        }

        throw new InvalidOperationException("Unknown failure during Azure Speech synthesis.");
    }
}