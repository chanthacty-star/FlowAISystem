//using System.Threading.Tasks;
//using FlowAISystem.Application.Common.Models;

//namespace FlowAISystem.Application.Interfaces;

//public interface ITextToSpeechService
//{
//    Task<SpeechSynthesisResultDto> SynthesizeExpressiveSpeechAsync(
//        string text,
//        string voiceName = "en-US-JennyNeural",
//        string? style = "cheerful",
//        double styleDegree = 1.2);
//}
using System.Threading;
using System.Threading.Tasks;
using FlowAISystem.Application.Common.Models;

namespace FlowAISystem.Application.Common.Interfaces;

public interface ITextToSpeechService
{
    /// <summary>
    /// Synthesizes speech from text or SSML using Azure Cognitive Services Speech SDK.
    /// Captures word-level timing offsets for UI timeline synchronization.
    /// </summary>
    /// <param name="request">The request payload containing script text, voice actor, style, and intensity.</param>
    /// <param name="cancellationToken">Cancellation token for aborting long-running synthesis requests.</param>
    /// <returns>A TtsResult object containing the synthesized audio stream, content type, duration, and word bookmarks.</returns>
    Task<TtsResult> SynthesizeAsync(TtsRequest request, CancellationToken cancellationToken = default);
}