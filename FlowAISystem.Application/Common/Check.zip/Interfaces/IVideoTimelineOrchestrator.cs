using FlowAISystem.Application.Common.Models;

namespace FlowAISystem.Application.Common.Interfaces;

public interface IVideoTimelineOrchestrator
{
    Task<VideoTimeline> BuildTimelineAsync(
        string rawLessonMarkdown,
        CancellationToken cancellationToken = default
    );

    Task<byte[]> ExportFinalVideoAsync(
        VideoTimeline timeline,
        CancellationToken cancellationToken = default
    );
}