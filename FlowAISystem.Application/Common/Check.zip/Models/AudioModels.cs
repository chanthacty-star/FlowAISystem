namespace FlowAISystem.Application.Common.Models;

public record TtsRequest(
    string Text,
    string VoiceName = "en-US-AriaNeural",
    double Speed = 1.0
);

public record TtsResult(
    byte[] AudioData,
    string ContentType = "audio/mp3",
    TimeSpan Duration = default
);

public record SttRequest(
    Stream AudioStream,
    string Language = "en-US"
);

public record SttResult(
    string Text,
    double Confidence
);