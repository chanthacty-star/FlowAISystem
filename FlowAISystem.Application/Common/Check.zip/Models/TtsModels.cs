using System;
using System.Collections.Generic;

namespace FlowAISystem.Application.Common.Models;

/// <summary>
/// Request payload containing the raw or SSML text script for text-to-speech synthesis.
/// </summary>
public record TtsRequest(
    string Text,
    string VoiceName = "en-US-JennyNeural",
    string? Style = null,
    double StyleDegree = 1.0
);

/// <summary>
/// Result payload containing synthesized audio stream metadata and word-level synchronization bookmarks.
/// </summary>
public record TtsResult(
    byte[] AudioData,
    string ContentType,
    TimeSpan Duration,
    IReadOnlyList<WordBookmark> WordBookmarks
);