using System;
using System.Collections.Generic;

namespace FlowAISystem.Application.Common.Models;

public record WordBookmark(
    string Word,
    TimeSpan Offset,
    TimeSpan Duration,
    uint TextOffset,
    uint WordLength
);

public record SpeechSynthesisResultDto(
    bool IsSuccess,
    byte[]? AudioData,
    List<WordBookmark> Bookmarks,
    string? ErrorMessage = null
);